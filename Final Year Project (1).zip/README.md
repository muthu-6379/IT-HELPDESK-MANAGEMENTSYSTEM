
  # Final Year Project

  This is a code bundle for Final Year Project. The original project is available at https://www.figma.com/design/QbwOYnINR5rUb10H6oZdnR/Final-Year-Project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  