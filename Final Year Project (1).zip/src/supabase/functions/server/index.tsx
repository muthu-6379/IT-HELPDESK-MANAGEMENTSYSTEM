import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-470bad71/health", (c) => {
  return c.json({ status: "ok" });
});

// Send OTP to email for registration
app.post("/make-server-470bad71/register/send-otp", async (c) => {
  try {
    const { email, fullName, department, phone, usePhone } = await c.req.json();

    if (!email && !phone) {
      return c.json({ error: "Email or phone is required" }, 400);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
    );

    // If usePhone is true, send OTP to phone number
    if (usePhone && phone) {
      // Format phone number to E.164 format (e.g., +916379359101 for India)
      let formattedPhone = phone;
      if (!phone.startsWith('+')) {
        // Assuming India country code +91
        formattedPhone = `+91${phone}`;
      }

      console.log(`Attempting to send OTP to phone: ${formattedPhone}`);

      const { data, error } = await supabase.auth.signInWithOtp({
        phone: formattedPhone,
        options: {
          data: {
            full_name: fullName,
            department,
            email,
          },
        },
      });

      if (error) {
        console.error(`Error sending OTP to ${formattedPhone}:`, error);
        return c.json({ 
          error: `Failed to send SMS OTP: ${error.message}. Note: Phone authentication requires Twilio setup in Supabase.` 
        }, 500);
      }

      console.log(`SMS OTP sent successfully to ${formattedPhone}`);
      return c.json({ 
        success: true, 
        message: `OTP has been sent to ${formattedPhone} via SMS. Please check your phone.`,
        phone: formattedPhone
      });
    }

    // Otherwise, send OTP to email
    if (!email) {
      return c.json({ error: "Email is required" }, 400);
    }

    // Send OTP to the user's email using Supabase Auth
    const { data, error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        data: {
          full_name: fullName,
          department,
          phone,
        },
      },
    });

    if (error) {
      console.error(`Error sending OTP to ${email}:`, error);
      return c.json({ error: `Failed to send OTP: ${error.message}` }, 500);
    }

    console.log(`OTP sent successfully to ${email}`);
    return c.json({ 
      success: true, 
      message: `OTP has been sent to ${email}. Please check your inbox.` 
    });
  } catch (error) {
    console.error("Error in send-otp endpoint:", error);
    return c.json({ error: `Server error while sending OTP: ${error}` }, 500);
  }
});

// Verify OTP and complete registration
app.post("/make-server-470bad71/register/verify-otp", async (c) => {
  try {
    const { email, phone, otp, fullName, department, usePhone } = await c.req.json();

    if (!otp) {
      return c.json({ error: "OTP is required" }, 400);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
    );

    let verifyData;
    let verifyError;
    let identifier;

    // Verify phone OTP
    if (usePhone && phone) {
      let formattedPhone = phone;
      if (!phone.startsWith('+')) {
        formattedPhone = `+91${phone}`;
      }
      identifier = formattedPhone;

      console.log(`Verifying OTP for phone: ${formattedPhone}`);

      const result = await supabase.auth.verifyOtp({
        phone: formattedPhone,
        token: otp,
        type: 'sms',
      });

      verifyData = result.data;
      verifyError = result.error;
    } 
    // Verify email OTP
    else {
      if (!email) {
        return c.json({ error: "Email is required for email OTP verification" }, 400);
      }
      identifier = email;

      console.log(`Verifying OTP for email: ${email}`);

      const result = await supabase.auth.verifyOtp({
        email,
        token: otp,
        type: 'email',
      });

      verifyData = result.data;
      verifyError = result.error;
    }

    if (verifyError) {
      console.error(`Error verifying OTP for ${identifier}:`, verifyError);
      return c.json({ error: `Invalid or expired OTP: ${verifyError.message}` }, 400);
    }

    if (!verifyData.user) {
      return c.json({ error: "OTP verification failed" }, 400);
    }

    // Store user information in KV store
    const userId = verifyData.user.id;
    await kv.set(`user:${userId}`, {
      id: userId,
      email: email || verifyData.user.email,
      phone: phone || verifyData.user.phone,
      fullName,
      department,
      role: 'user', // Default role
      createdAt: new Date().toISOString(),
    });

    console.log(`User ${identifier} registered successfully with ID ${userId}`);
    return c.json({ 
      success: true, 
      message: "Registration successful!",
      user: {
        id: userId,
        email: email || verifyData.user.email,
        phone: phone || verifyData.user.phone,
        fullName,
      }
    });
  } catch (error) {
    console.error("Error in verify-otp endpoint:", error);
    return c.json({ error: `Server error while verifying OTP: ${error}` }, 500);
  }
});

Deno.serve(app.fetch);