import { useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { Dashboard } from './components/Dashboard';
import { TicketsPage } from './components/TicketsPage';
import { CreateTicketPage } from './components/CreateTicketPage';
import { TicketDetailsPage } from './components/TicketDetailsPage';
import { UsersPage } from './components/UsersPage';
import { KnowledgeBasePage } from './components/KnowledgeBasePage';
import { ReportsPage } from './components/ReportsPage';
import { SettingsPage } from './components/SettingsPage';
import { Sidebar } from './components/Sidebar';

export type Page = 'login' | 'register' | 'dashboard' | 'tickets' | 'create-ticket' | 'ticket-details' | 'users' | 'knowledge-base' | 'reports' | 'settings';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'agent' | 'user';
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    setCurrentPage('login');
  };

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
  };

  const handleViewTicket = (ticketId: string) => {
    setSelectedTicketId(ticketId);
    setCurrentPage('ticket-details');
  };

  // Render authentication pages
  if (!isAuthenticated) {
    if (currentPage === 'register') {
      return <RegisterPage onNavigateToLogin={() => setCurrentPage('login')} />;
    }
    return <LoginPage onLogin={handleLogin} onNavigateToRegister={() => setCurrentPage('register')} />;
  }

  // Render main application with sidebar
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar 
        currentPage={currentPage} 
        onNavigate={handleNavigate} 
        onLogout={handleLogout}
        currentUser={currentUser}
      />
      <main className="flex-1 ml-64">
        {currentPage === 'dashboard' && <Dashboard onNavigate={handleNavigate} onViewTicket={handleViewTicket} />}
        {currentPage === 'tickets' && <TicketsPage onViewTicket={handleViewTicket} onNavigate={handleNavigate} />}
        {currentPage === 'create-ticket' && <CreateTicketPage onNavigate={handleNavigate} />}
        {currentPage === 'ticket-details' && <TicketDetailsPage ticketId={selectedTicketId} onNavigate={handleNavigate} />}
        {currentPage === 'users' && currentUser?.role === 'admin' && <UsersPage />}
        {currentPage === 'knowledge-base' && <KnowledgeBasePage />}
        {currentPage === 'reports' && (currentUser?.role === 'admin' || currentUser?.role === 'agent') && <ReportsPage />}
        {currentPage === 'settings' && <SettingsPage currentUser={currentUser} />}
      </main>
    </div>
  );
}
