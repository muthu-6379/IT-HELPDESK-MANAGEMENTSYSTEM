# 📱 SMS OTP Registration - Setup Guide

## ✅ What's Been Updated

Your IT Desk Management System now supports **BOTH** OTP methods:

### 1. 📱 **Phone SMS OTP** (Default)
- Send OTP to: **+91-6379359101**
- Receive 6-digit code via SMS
- Instant delivery to your phone

### 2. 📧 **Email OTP** (Fallback)
- Send OTP to: **mlakshmi9101@gmail.com**
- Receive 6-digit code via email
- Check inbox and spam folder

---

## 🚀 How to Register with SMS OTP

### Step 1: Choose OTP Method
1. Open the Register page
2. You'll see two buttons at the top:
   - **📱 Phone SMS** (Selected by default)
   - **📧 Email** (Click to switch)

### Step 2: Fill Your Details
Pre-filled for you:
- **Full Name:** Muthulakshmi
- **Phone Number:** +91-6379359101
- **Email:** mlakshmi9101@gmail.com (optional when using SMS)
- **Department:** Choose from dropdown

### Step 3: Send SMS OTP
1. Make sure "Phone SMS" is selected
2. Your phone shows: **+91-6379359101**
3. Click **"📱 Send SMS OTP"** button
4. Wait for SMS to arrive on your phone

### Step 4: Enter OTP from SMS
1. Check your phone messages for SMS from Supabase
2. You'll receive a **6-digit code**
3. Enter the code in the large input field
4. Click **"✓ Verify OTP & Complete Registration"**

### Step 5: Success!
- See "Registration Successful!" message
- Automatically redirected to login page

---

## ⚠️ IMPORTANT: Twilio Setup Required for SMS

**SMS OTP requires additional setup in Supabase:**

### To Enable SMS OTP:

1. **Go to Supabase Dashboard:**
   - Visit: https://supabase.com/dashboard
   - Select your project

2. **Navigate to Authentication > Providers**
   - Click on "Phone Auth"
   
3. **Setup Twilio (Required for SMS):**
   
   **Option A: Use Supabase's Phone Auth (Recommended for testing)**
   - Enable "Phone" provider
   - Follow Supabase's guided setup
   
   **Option B: Configure Custom Twilio Account**
   - Sign up for Twilio: https://www.twilio.com
   - Get your Twilio credentials:
     - Account SID
     - Auth Token
     - Phone Number
   - Add these to Supabase Phone Auth settings

4. **Save Settings**

### If SMS is Not Configured:

You'll see this error:
```
⚠️ SMS service not configured. Please use Email OTP instead, or contact support to enable SMS.
```

**Solution:** Switch to Email OTP by clicking the "📧 Email" button at the top.

---

## 🔄 Switch Between SMS and Email

### Use SMS OTP (Default):
1. Click **"📱 Phone SMS"** button
2. Enter your 10-digit phone number
3. Format: `6379359101` (country code +91 added automatically)
4. Click "📱 Send SMS OTP"

### Use Email OTP:
1. Click **"📧 Email"** button
2. Enter your email address
3. Format: `mlakshmi9101@gmail.com`
4. Click "📧 Send Email OTP"

---

## 📱 Phone Number Format

### Your Phone: **6379359101**

**Automatic formatting:**
- You enter: `6379359101` (10 digits)
- System adds: `+91` (India country code)
- SMS sent to: `+916379359101`

**Supported format:**
- ✅ `6379359101` (10 digits, no spaces)
- ✅ Country code automatically added (+91 for India)
- ❌ Don't include +91, spaces, or dashes

---

## 🐛 Troubleshooting

### SMS Not Received?

**Check 1: Twilio Setup**
- Is Phone Auth enabled in Supabase?
- Are Twilio credentials configured?
- If not → Use Email OTP instead

**Check 2: Phone Number**
- Is it 10 digits: `6379359101`?
- No spaces or special characters?
- Valid Indian mobile number?

**Check 3: Network**
- SMS delivery can take 10-30 seconds
- Check your phone's message inbox
- Try "Resend OTP" if needed

**Check 4: Backend Connection**
- Click "🔧 Test Backend Connection"
- Should show "✅ Backend is connected and working!"

### Email Not Received?

**Check 1: Email Address**
- Correct: `mlakshmi9101@gmail.com`
- Check for typos

**Check 2: Spam Folder**
- Check Gmail spam/junk folder
- OTP emails sometimes go to spam

**Check 3: Wait**
- Email can take 1-2 minutes
- Check inbox again
- Try "Resend OTP"

### Invalid OTP Error?

**Causes:**
- OTP expired (typically 1-5 minutes)
- Wrong code entered
- Used an old OTP

**Solution:**
- Click "Resend OTP" to get a new code
- Enter the new 6-digit code
- Submit within 5 minutes

---

## 🔧 Backend API Details

### Send SMS OTP
```javascript
POST /make-server-470bad71/register/send-otp

Body:
{
  "fullName": "Muthulakshmi",
  "phone": "6379359101",
  "email": "mlakshmi9101@gmail.com",
  "department": "engineering",
  "usePhone": true  // ← SMS mode
}

Response:
{
  "success": true,
  "message": "OTP has been sent to +916379359101 via SMS",
  "phone": "+916379359101"
}
```

### Verify SMS OTP
```javascript
POST /make-server-470bad71/register/verify-otp

Body:
{
  "fullName": "Muthulakshmi",
  "phone": "6379359101",
  "otp": "123456",
  "department": "engineering",
  "usePhone": true  // ← SMS mode
}

Response:
{
  "success": true,
  "message": "Registration successful!",
  "user": {
    "id": "uuid",
    "phone": "+916379359101",
    "fullName": "Muthulakshmi"
  }
}
```

---

## 📊 Testing Checklist

### SMS OTP Testing:
- [ ] Click "📱 Phone SMS" button (selected by default)
- [ ] See phone field with +91 prefix
- [ ] Phone number pre-filled: `6379359101`
- [ ] Click "📱 Send SMS OTP"
- [ ] Check console logs
- [ ] Wait for SMS on phone
- [ ] Enter 6-digit OTP code
- [ ] Click "Verify OTP"
- [ ] See success message

### Email OTP Testing (Fallback):
- [ ] Click "📧 Email" button
- [ ] See email field
- [ ] Email pre-filled: `mlakshmi9101@gmail.com`
- [ ] Click "📧 Send Email OTP"
- [ ] Check email inbox & spam
- [ ] Enter 6-digit OTP code
- [ ] Click "Verify OTP"
- [ ] See success message

---

## 💡 Quick Start Guide

**For immediate testing:**

### Option 1: SMS OTP (Requires Twilio)
```
1. Make sure Twilio is configured in Supabase
2. Phone already filled: 6379359101
3. Click "📱 Send SMS OTP"
4. Check your phone for SMS
5. Enter 6-digit code
6. Done!
```

### Option 2: Email OTP (Works immediately)
```
1. Click "📧 Email" button at top
2. Email already filled: mlakshmi9101@gmail.com
3. Click "📧 Send Email OTP"
4. Check email inbox (and spam)
5. Enter 6-digit code
6. Done!
```

---

## 🎯 Recommendation

**Start with Email OTP first** to test the flow, since it works without additional setup.

**Once you confirm Twilio is configured**, switch to SMS OTP for faster delivery.

---

## 📞 Support

If you encounter issues:

1. **Check Console Logs** (F12 in browser)
2. **Click "Test Backend Connection"** button
3. **Try Email OTP** if SMS doesn't work
4. **Verify Twilio Setup** in Supabase Dashboard

---

**Your dual OTP system is ready! 🎉**

Choose SMS for instant delivery or Email for reliable delivery.
