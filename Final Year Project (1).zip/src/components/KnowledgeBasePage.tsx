import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, BookOpen, FileText, HelpCircle, Lightbulb, Wrench } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

export function KnowledgeBasePage() {
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'getting-started', name: 'Getting Started', icon: Lightbulb, count: 12, color: 'bg-yellow-100 text-yellow-600' },
    { id: 'common-issues', name: 'Common Issues', icon: HelpCircle, count: 28, color: 'bg-blue-100 text-blue-600' },
    { id: 'how-to', name: 'How-To Guides', icon: BookOpen, count: 35, color: 'bg-green-100 text-green-600' },
    { id: 'troubleshooting', name: 'Troubleshooting', icon: Wrench, count: 42, color: 'bg-orange-100 text-orange-600' },
  ];

  const articles = [
    {
      id: '1',
      title: 'How to Reset Your Password',
      category: 'getting-started',
      views: 1243,
      helpful: 156,
      summary: 'Step-by-step guide to reset your password if you\'ve forgotten it or need to change it for security reasons.',
      tags: ['password', 'account', 'security'],
    },
    {
      id: '2',
      title: 'Connecting to VPN',
      category: 'how-to',
      views: 987,
      helpful: 142,
      summary: 'Learn how to connect to the company VPN for secure remote access to internal resources.',
      tags: ['vpn', 'network', 'remote'],
    },
    {
      id: '3',
      title: 'Email Not Syncing - Solutions',
      category: 'common-issues',
      views: 856,
      helpful: 98,
      summary: 'Common solutions for email synchronization issues across different email clients.',
      tags: ['email', 'outlook', 'sync'],
    },
    {
      id: '4',
      title: 'Installing Approved Software',
      category: 'how-to',
      views: 734,
      helpful: 89,
      summary: 'Guidelines and procedures for requesting and installing company-approved software.',
      tags: ['software', 'installation', 'permissions'],
    },
    {
      id: '5',
      title: 'Troubleshooting Printer Issues',
      category: 'troubleshooting',
      views: 923,
      helpful: 123,
      summary: 'Common printer problems and their solutions, including connection issues and print quality.',
      tags: ['printer', 'hardware', 'printing'],
    },
    {
      id: '6',
      title: 'Setting Up Multi-Factor Authentication',
      category: 'getting-started',
      views: 1156,
      helpful: 178,
      summary: 'Enable MFA to add an extra layer of security to your account.',
      tags: ['security', 'mfa', 'authentication'],
    },
    {
      id: '7',
      title: 'Accessing Shared Drives',
      category: 'how-to',
      views: 645,
      helpful: 72,
      summary: 'How to access and map shared network drives for file collaboration.',
      tags: ['files', 'network', 'collaboration'],
    },
    {
      id: '8',
      title: 'Laptop Battery Not Charging',
      category: 'troubleshooting',
      views: 512,
      helpful: 56,
      summary: 'Diagnose and fix laptop battery charging issues.',
      tags: ['laptop', 'battery', 'hardware'],
    },
  ];

  const filterArticles = (category?: string) => {
    return articles.filter(article => {
      const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           article.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCategory = !category || article.category === category;
      return matchesSearch && matchesCategory;
    });
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Knowledge Base</h1>
        <p className="text-gray-600">Find answers and learn how to resolve common issues</p>
      </div>

      {/* Search */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-5 text-gray-400" />
            <Input
              placeholder="Search for articles, guides, and solutions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-12"
            />
          </div>
        </CardContent>
      </Card>

      {/* Categories */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
        {categories.map((category) => (
          <Card key={category.id} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-6">
              <div className={`${category.color} p-3 rounded-lg w-fit mb-4`}>
                <category.icon className="size-6" />
              </div>
              <h3 className="mb-1">{category.name}</h3>
              <p className="text-sm text-gray-600">{category.count} articles</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Articles */}
      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all">All Articles</TabsTrigger>
          <TabsTrigger value="popular">Most Popular</TabsTrigger>
          <TabsTrigger value="recent">Recently Added</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <Card>
            <CardContent className="pt-6">
              <div className="grid gap-4 md:grid-cols-2">
                {filterArticles().map((article) => (
                  <div
                    key={article.id}
                    className="p-4 border rounded-lg hover:shadow-sm transition-all cursor-pointer"
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <div className="bg-blue-50 p-2 rounded">
                        <FileText className="size-5 text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="mb-1">{article.title}</h3>
                        <p className="text-sm text-gray-600 line-clamp-2">{article.summary}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {article.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                      ))}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>{article.views} views</span>
                      <span>•</span>
                      <span>{article.helpful} found helpful</span>
                    </div>
                  </div>
                ))}
              </div>
              {filterArticles().length === 0 && (
                <div className="text-center py-12 text-gray-500">
                  <p>No articles found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="popular">
          <Card>
            <CardContent className="pt-6">
              <div className="grid gap-4 md:grid-cols-2">
                {filterArticles()
                  .sort((a, b) => b.views - a.views)
                  .map((article) => (
                    <div
                      key={article.id}
                      className="p-4 border rounded-lg hover:shadow-sm transition-all cursor-pointer"
                    >
                      <div className="flex items-start gap-3 mb-3">
                        <div className="bg-blue-50 p-2 rounded">
                          <FileText className="size-5 text-blue-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="mb-1">{article.title}</h3>
                          <p className="text-sm text-gray-600 line-clamp-2">{article.summary}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {article.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                        ))}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span>{article.views} views</span>
                        <span>•</span>
                        <span>{article.helpful} found helpful</span>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recent">
          <Card>
            <CardContent className="pt-6">
              <div className="grid gap-4 md:grid-cols-2">
                {filterArticles()
                  .reverse()
                  .map((article) => (
                    <div
                      key={article.id}
                      className="p-4 border rounded-lg hover:shadow-sm transition-all cursor-pointer"
                    >
                      <div className="flex items-start gap-3 mb-3">
                        <div className="bg-blue-50 p-2 rounded">
                          <FileText className="size-5 text-blue-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="mb-1">{article.title}</h3>
                          <p className="text-sm text-gray-600 line-clamp-2">{article.summary}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {article.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                        ))}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span>{article.views} views</span>
                        <span>•</span>
                        <span>{article.helpful} found helpful</span>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
