import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Headphones, AlertCircle, CheckCircle2, Mail, Info, Smartphone } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface RegisterPageProps {
  onNavigateToLogin: () => void;
}

export function RegisterPage({ onNavigateToLogin }: RegisterPageProps) {
  const [formData, setFormData] = useState({
    fullName: 'Muthulakshmi',
    email: 'mlakshmi9101@gmail.com',
    department: '',
    phone: '6379359101',
  });
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [message, setMessage] = useState('');
  const [showDebug, setShowDebug] = useState(false);
  const [usePhone, setUsePhone] = useState(true); // Default to phone OTP

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const testBackendConnection = async () => {
    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-470bad71/health`;
      console.log('🔍 Testing backend connection:', url);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });

      const data = await response.json();
      console.log('✅ Backend response:', data);
      
      if (response.ok && data.status === 'ok') {
        setMessage('✅ Backend is connected and working!');
        setError('');
      } else {
        setError('⚠️ Backend responded but returned unexpected data');
      }
    } catch (err: any) {
      console.error('❌ Backend connection failed:', err);
      setError(`❌ Cannot connect to backend: ${err.message}`);
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setIsLoading(true);

    // Validation
    if (usePhone) {
      if (!formData.phone || !formData.fullName) {
        setError('Please fill in phone number and full name');
        setIsLoading(false);
        return;
      }
      // Phone validation (10 digits)
      if (!/^\d{10}$/.test(formData.phone)) {
        setError('Please enter a valid 10-digit phone number');
        setIsLoading(false);
        return;
      }
    } else {
      if (!formData.email || !formData.fullName) {
        setError('Please fill in all required fields');
        setIsLoading(false);
        return;
      }
      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        setError('Please enter a valid email address');
        setIsLoading(false);
        return;
      }
    }

    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-470bad71/register/send-otp`;
      console.log('🚀 Sending OTP request to:', url);
      console.log(`📱 Method: ${usePhone ? 'SMS' : 'Email'}`);
      console.log(usePhone ? `📞 Phone: +91${formData.phone}` : `📧 Email: ${formData.email}`);
      console.log('👤 Name:', formData.fullName);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({
          email: formData.email,
          fullName: formData.fullName,
          department: formData.department,
          phone: formData.phone,
          usePhone: usePhone,
        }),
      });

      console.log('📨 Response status:', response.status);
      
      const data = await response.json();
      console.log('📦 Response data:', data);

      if (!response.ok) {
        throw new Error(data.error || 'Failed to send OTP');
      }

      setOtpSent(true);
      if (usePhone) {
        setMessage(`✅ SMS OTP has been sent to +91${formData.phone}. Please check your phone messages.`);
      } else {
        setMessage(`✅ OTP has been sent to ${formData.email}. Please check your email inbox (and spam folder).`);
      }
      console.log('✅ OTP sent successfully!');
    } catch (err: any) {
      console.error('❌ Error sending OTP:', err);
      let errorMessage = err.message || 'Failed to send OTP. Please try again.';
      
      // Show more helpful error message
      if (err.message?.includes('Failed to fetch') || err.message?.includes('NetworkError')) {
        errorMessage = 'Network error: Unable to connect to server. Please check your internet connection.';
      } else if (err.message?.includes('Twilio')) {
        errorMessage = '⚠️ SMS service not configured. Please use Email OTP instead, or contact support to enable SMS.';
      }
      
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setIsLoading(true);

    if (!otp) {
      setError('Please enter the OTP code');
      setIsLoading(false);
      return;
    }

    if (otp.length !== 6) {
      setError('OTP must be 6 digits');
      setIsLoading(false);
      return;
    }

    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-470bad71/register/verify-otp`;
      console.log('🔐 Verifying OTP...');

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({
          email: formData.email,
          phone: formData.phone,
          otp: otp,
          fullName: formData.fullName,
          department: formData.department,
          usePhone: usePhone,
        }),
      });

      const data = await response.json();
      console.log('📦 Verification response:', data);

      if (!response.ok) {
        throw new Error(data.error || 'Failed to verify OTP');
      }

      console.log('✅ Registration successful!');
      setSuccess(true);
      setMessage('🎉 Registration successful! Redirecting to login...');
      
      setTimeout(() => {
        onNavigateToLogin();
      }, 2000);
    } catch (err: any) {
      console.error('❌ Error verifying OTP:', err);
      setError(err.message || 'Invalid OTP. Please check the code and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="mx-auto bg-green-100 p-3 rounded-full w-fit">
                <CheckCircle2 className="size-12 text-green-600" />
              </div>
              <h2 className="text-green-600">Registration Successful!</h2>
              <p className="text-gray-600">
                Your account has been created successfully.
              </p>
              <p className="text-sm text-gray-500">Redirecting to login page...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-3 text-center">
          <div className="mx-auto bg-gradient-to-br from-blue-600 to-indigo-600 p-3 rounded-lg w-fit">
            <Headphones className="size-8 text-white" />
          </div>
          <CardTitle>Create Account with OTP</CardTitle>
          <CardDescription>
            {otpSent ? 'Enter the OTP code sent to your ' + (usePhone ? 'phone' : 'email') : 'Register to access IT support services'}
          </CardDescription>
        </CardHeader>
        <form onSubmit={otpSent ? handleVerifyOtp : handleSendOtp}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="size-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            {message && (
              <Alert className="border-green-200 bg-green-50">
                {usePhone ? <Smartphone className="size-4 text-green-600" /> : <Mail className="size-4 text-green-600" />}
                <AlertDescription className="text-green-800">{message}</AlertDescription>
              </Alert>
            )}

            {!otpSent && (
              <Alert className="border-blue-200 bg-blue-50">
                <Info className="size-4 text-blue-600" />
                <AlertDescription className="text-blue-800 text-sm">
                  OTP will be sent to your {usePhone ? 'phone number via SMS' : 'email address'}.
                </AlertDescription>
              </Alert>
            )}
            
            {!otpSent ? (
              <>
                {/* OTP Method Toggle */}
                <div className="flex gap-2 p-1 bg-gray-100 rounded-lg">
                  <Button
                    type="button"
                    variant={usePhone ? "default" : "ghost"}
                    className="flex-1"
                    onClick={() => setUsePhone(true)}
                  >
                    <Smartphone className="size-4 mr-2" />
                    Phone SMS
                  </Button>
                  <Button
                    type="button"
                    variant={!usePhone ? "default" : "ghost"}
                    className="flex-1"
                    onClick={() => setUsePhone(false)}
                  >
                    <Mail className="size-4 mr-2" />
                    Email
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name *</Label>
                  <Input
                    id="fullName"
                    placeholder="Enter your full name"
                    value={formData.fullName}
                    onChange={(e) => handleChange('fullName', e.target.value)}
                    required
                  />
                </div>

                {usePhone ? (
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number * (10 digits)</Label>
                    <div className="flex gap-2">
                      <div className="flex items-center px-3 bg-gray-100 rounded-md border">
                        <span className="text-gray-700">+91</span>
                      </div>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="6379359101"
                        value={formData.phone}
                        onChange={(e) => handleChange('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                        required
                        className="flex-1"
                      />
                    </div>
                    <p className="text-xs text-gray-500">SMS OTP will be sent to +91{formData.phone}</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your.email@example.com"
                      value={formData.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      required
                    />
                    <p className="text-xs text-gray-500">OTP will be sent to this email</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="department">Department</Label>
                    <Select value={formData.department} onValueChange={(value) => handleChange('department', value)}>
                      <SelectTrigger id="department">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="engineering">Engineering</SelectItem>
                        <SelectItem value="sales">Sales</SelectItem>
                        <SelectItem value="marketing">Marketing</SelectItem>
                        <SelectItem value="hr">Human Resources</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="operations">Operations</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {!usePhone && (
                    <div className="space-y-2">
                      <Label htmlFor="phone2">Phone (Optional)</Label>
                      <Input
                        id="phone2"
                        type="tel"
                        placeholder="10 digits"
                        value={formData.phone}
                        onChange={(e) => handleChange('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                      />
                    </div>
                  )}
                  
                  {usePhone && (
                    <div className="space-y-2">
                      <Label htmlFor="email2">Email (Optional)</Label>
                      <Input
                        id="email2"
                        type="email"
                        placeholder="Optional"
                        value={formData.email}
                        onChange={(e) => handleChange('email', e.target.value)}
                      />
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="otp">Enter 6-Digit OTP Code *</Label>
                <Input
                  id="otp"
                  type="text"
                  placeholder="000000"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  maxLength={6}
                  required
                  className="text-center tracking-widest text-2xl font-mono"
                />
                <p className="text-xs text-gray-600">
                  {usePhone ? (
                    <>📱 Check your phone <strong>+91{formData.phone}</strong> for the 6-digit SMS code</>
                  ) : (
                    <>✉️ Check your email <strong>{formData.email}</strong> for the 6-digit OTP code</>
                  )}
                </p>
                {!usePhone && (
                  <p className="text-xs text-gray-500">
                    Don't forget to check your spam/junk folder if you don't see it
                  </p>
                )}
              </div>
            )}
          </CardContent>
          <CardFooter className="flex flex-col gap-3">
            {otpSent ? (
              <>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Verifying OTP...' : '✓ Verify OTP & Complete Registration'}
                </Button>
                <div className="flex gap-2 w-full">
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setOtpSent(false);
                      setOtp('');
                      setError('');
                      setMessage('');
                    }}
                  >
                    ← Back
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={handleSendOtp}
                    disabled={isLoading}
                  >
                    Resend OTP
                  </Button>
                </div>
              </>
            ) : (
              <>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Sending OTP...' : (usePhone ? '📱 Send SMS OTP' : '📧 Send Email OTP')}
                </Button>
                
                {/* Debug: Test Backend Connection */}
                <Button
                  type="button"
                  variant="outline"
                  className="w-full text-xs"
                  onClick={() => {
                    testBackendConnection();
                    setShowDebug(true);
                  }}
                >
                  🔧 Test Backend Connection
                </Button>
              </>
            )}
            
            {showDebug && !otpSent && (
              <div className="w-full text-xs text-gray-600 p-2 bg-gray-50 rounded border">
                <p><strong>Backend URL:</strong></p>
                <p className="break-all">https://{projectId}.supabase.co/functions/v1/make-server-470bad71</p>
                <p className="mt-2"><strong>OTP Method:</strong> {usePhone ? 'SMS to +91' + formData.phone : 'Email to ' + formData.email}</p>
              </div>
            )}
            
            <p className="text-sm text-center text-gray-600">
              Already have an account?{' '}
              <button
                type="button"
                onClick={onNavigateToLogin}
                className="text-blue-600 hover:underline"
              >
                Sign in here
              </button>
            </p>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
