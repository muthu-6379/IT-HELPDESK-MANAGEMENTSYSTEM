import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { FileText, Upload, Download, Eye, Trash2, Search } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from './ui/dialog';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface Document {
  id: string;
  name: string;
  type: string;
  category: string;
  size: string;
  uploadDate: string;
  uploadedBy: string;
}

export function Documents() {
  const [searchQuery, setSearchQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [documents, setDocuments] = useState<Document[]>([
    {
      id: '1',
      name: 'Project Proposal.pdf',
      type: 'PDF',
      category: 'Proposal',
      size: '2.4 MB',
      uploadDate: '2024-09-15',
      uploadedBy: 'John Doe',
    },
    {
      id: '2',
      name: 'Literature Review.docx',
      type: 'DOCX',
      category: 'Research',
      size: '1.8 MB',
      uploadDate: '2024-10-20',
      uploadedBy: 'Jane Smith',
    },
    {
      id: '3',
      name: 'System Architecture.pdf',
      type: 'PDF',
      category: 'Design',
      size: '3.2 MB',
      uploadDate: '2024-11-05',
      uploadedBy: 'John Doe',
    },
    {
      id: '4',
      name: 'Database Schema.sql',
      type: 'SQL',
      category: 'Technical',
      size: '45 KB',
      uploadDate: '2024-11-08',
      uploadedBy: 'Mike Wilson',
    },
    {
      id: '5',
      name: 'UI Mockups.fig',
      type: 'FIG',
      category: 'Design',
      size: '5.6 MB',
      uploadDate: '2024-11-10',
      uploadedBy: 'Sarah Johnson',
    },
    {
      id: '6',
      name: 'Progress Report.pdf',
      type: 'PDF',
      category: 'Reports',
      size: '890 KB',
      uploadDate: '2024-11-12',
      uploadedBy: 'John Doe',
    },
  ]);

  const [newDocument, setNewDocument] = useState({
    name: '',
    category: 'Research',
  });

  const filteredDocuments = documents.filter(doc =>
    doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUpload = () => {
    const doc: Document = {
      id: Date.now().toString(),
      name: newDocument.name,
      type: newDocument.name.split('.').pop()?.toUpperCase() || 'FILE',
      category: newDocument.category,
      size: '1.2 MB',
      uploadDate: new Date().toISOString().split('T')[0],
      uploadedBy: 'Current User',
    };
    setDocuments([doc, ...documents]);
    setNewDocument({ name: '', category: 'Research' });
    setDialogOpen(false);
  };

  const handleDelete = (id: string) => {
    setDocuments(documents.filter(doc => doc.id !== id));
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'Proposal': 'bg-purple-100 text-purple-800',
      'Research': 'bg-blue-100 text-blue-800',
      'Design': 'bg-green-100 text-green-800',
      'Technical': 'bg-orange-100 text-orange-800',
      'Reports': 'bg-pink-100 text-pink-800',
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Document Management</CardTitle>
              <CardDescription>Store and organize all project documents</CardDescription>
            </div>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Upload className="size-4 mr-2" />
                  Upload Document
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Upload New Document</DialogTitle>
                  <DialogDescription>Add a new document to your project</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="docName">Document Name</Label>
                    <Input
                      id="docName"
                      value={newDocument.name}
                      onChange={(e) => setNewDocument({ ...newDocument, name: e.target.value })}
                      placeholder="e.g., Research Paper.pdf"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select value={newDocument.category} onValueChange={(value) => setNewDocument({ ...newDocument, category: value })}>
                      <SelectTrigger id="category">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Proposal">Proposal</SelectItem>
                        <SelectItem value="Research">Research</SelectItem>
                        <SelectItem value="Design">Design</SelectItem>
                        <SelectItem value="Technical">Technical</SelectItem>
                        <SelectItem value="Reports">Reports</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="border-2 border-dashed rounded-lg p-8 text-center">
                    <Upload className="size-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-600">Click or drag file to upload</p>
                    <p className="text-xs text-gray-500 mt-1">PDF, DOC, DOCX, XLS, XLSX up to 10MB</p>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
                  <Button onClick={handleUpload} disabled={!newDocument.name}>Upload</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-4 text-gray-400" />
            <Input
              placeholder="Search documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Document List */}
          <div className="space-y-3">
            {filteredDocuments.map(doc => (
              <div key={doc.id} className="flex items-center gap-4 p-4 bg-white border rounded-lg hover:shadow-sm transition-shadow">
                <div className="bg-blue-50 p-3 rounded-lg flex-shrink-0">
                  <FileText className="size-6 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4 mb-1">
                    <h3 className="truncate">{doc.name}</h3>
                    <Badge className={getCategoryColor(doc.category)}>{doc.category}</Badge>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-500">
                    <span>{doc.size}</span>
                    <span>•</span>
                    <span>Uploaded {doc.uploadDate}</span>
                    <span>•</span>
                    <span>{doc.uploadedBy}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Button variant="ghost" size="sm">
                    <Eye className="size-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Download className="size-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(doc.id)}>
                    <Trash2 className="size-4 text-red-600" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
