import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { ArrowLeft, Clock, User, Tag, MessageSquare, Paperclip, Send } from 'lucide-react';
import type { Page } from '../App';

interface TicketDetailsPageProps {
  ticketId: string | null;
  onNavigate: (page: Page) => void;
}

export function TicketDetailsPage({ ticketId, onNavigate }: TicketDetailsPageProps) {
  const [comment, setComment] = useState('');
  const [status, setStatus] = useState('open');
  const [priority, setPriority] = useState('high');

  // Mock ticket data
  const ticket = {
    id: ticketId || 'TKT-1001',
    title: 'Cannot access email account',
    description: 'I have been unable to access my email account since this morning. When I try to log in, I get an error message saying "Invalid credentials" even though I\'m using the correct password. I\'ve tried resetting my password but haven\'t received the reset email. This is urgent as I need to access important client emails.',
    status: 'open',
    priority: 'high',
    category: 'Email',
    createdBy: 'John Smith',
    createdDate: '2024-11-13 09:30 AM',
    assignedTo: 'Agent Sarah Wilson',
    department: 'Sales',
  };

  const comments = [
    {
      id: '1',
      author: 'John Smith',
      role: 'User',
      content: 'I have been unable to access my email account since this morning.',
      timestamp: '2024-11-13 09:30 AM',
    },
    {
      id: '2',
      author: 'Agent Sarah Wilson',
      role: 'Support Agent',
      content: 'Hi John, I\'m looking into this issue. Can you confirm which email client you\'re using (Outlook, Gmail, etc.)?',
      timestamp: '2024-11-13 09:45 AM',
    },
    {
      id: '3',
      author: 'John Smith',
      role: 'User',
      content: 'I\'m using Outlook 2021. I also tried accessing via webmail but same issue.',
      timestamp: '2024-11-13 10:00 AM',
    },
    {
      id: '4',
      author: 'Agent Sarah Wilson',
      role: 'Support Agent',
      content: 'Thank you. I\'ve checked your account and noticed it was temporarily locked due to multiple failed login attempts. I\'ve unlocked it. Please try logging in again with your current password.',
      timestamp: '2024-11-13 10:15 AM',
    },
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-100 text-blue-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleAddComment = () => {
    if (comment.trim()) {
      // Add comment logic here
      setComment('');
    }
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <Button variant="ghost" onClick={() => onNavigate('tickets')} className="mb-4">
          <ArrowLeft className="size-4 mr-2" />
          Back to Tickets
        </Button>
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-gray-900">{ticket.id}</h1>
              <Badge className={getStatusColor(status)}>{status}</Badge>
              <Badge className={getPriorityColor(priority)}>{priority}</Badge>
            </div>
            <p className="text-gray-600">{ticket.title}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">Close Ticket</Button>
            <Button>Resolve</Button>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Ticket Details */}
          <Card>
            <CardHeader>
              <CardTitle>Ticket Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-2">Description</p>
                  <p className="text-sm">{ticket.description}</p>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Paperclip className="size-4 text-gray-400" />
                  <span className="text-gray-600">No attachments</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Comments */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Comments & Activity</CardTitle>
                <Badge variant="outline">{comments.length} comments</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Comment List */}
              <div className="space-y-4">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <Avatar className="size-10">
                      <AvatarFallback>{comment.author.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-sm">{comment.author}</span>
                          <Badge variant="outline" className="text-xs">{comment.role}</Badge>
                          <span className="text-xs text-gray-500">{comment.timestamp}</span>
                        </div>
                        <p className="text-sm text-gray-700">{comment.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Comment */}
              <div className="space-y-3 pt-4 border-t">
                <Textarea
                  placeholder="Add a comment or update..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={3}
                />
                <div className="flex justify-between items-center">
                  <Button variant="ghost" size="sm">
                    <Paperclip className="size-4 mr-2" />
                    Attach File
                  </Button>
                  <Button onClick={handleAddComment}>
                    <Send className="size-4 mr-2" />
                    Add Comment
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Ticket Info */}
          <Card>
            <CardHeader>
              <CardTitle>Ticket Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm text-gray-600">Status</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm text-gray-600">Priority</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="pt-4 border-t space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <User className="size-4 text-gray-400" />
                  <div>
                    <p className="text-gray-600">Created by</p>
                    <p>{ticket.createdBy}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-sm">
                  <Clock className="size-4 text-gray-400" />
                  <div>
                    <p className="text-gray-600">Created on</p>
                    <p>{ticket.createdDate}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-sm">
                  <User className="size-4 text-gray-400" />
                  <div>
                    <p className="text-gray-600">Assigned to</p>
                    <p>{ticket.assignedTo}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-sm">
                  <Tag className="size-4 text-gray-400" />
                  <div>
                    <p className="text-gray-600">Category</p>
                    <p>{ticket.category}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-sm">
                  <Tag className="size-4 text-gray-400" />
                  <div>
                    <p className="text-gray-600">Department</p>
                    <p>{ticket.department}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}