import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Calendar, MessageSquare, UserPlus, Send, Video } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from './ui/dialog';
import { Label } from './ui/label';

interface TeamMember {
  id: string;
  name: string;
  role: string;
  email: string;
  avatar?: string;
  status: 'active' | 'away' | 'offline';
}

interface Meeting {
  id: string;
  title: string;
  date: string;
  time: string;
  attendees: string[];
  type: 'supervisor' | 'team' | 'presentation';
}

interface Message {
  id: string;
  author: string;
  content: string;
  timestamp: string;
}

export function TeamCollaboration() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [messageInput, setMessageInput] = useState('');
  
  const [teamMembers] = useState<TeamMember[]>([
    {
      id: '1',
      name: 'John Doe',
      role: 'Project Lead',
      email: 'john.doe@university.edu',
      status: 'active',
    },
    {
      id: '2',
      name: 'Jane Smith',
      role: 'Developer',
      email: 'jane.smith@university.edu',
      status: 'active',
    },
    {
      id: '3',
      name: 'Mike Wilson',
      role: 'Developer',
      email: 'mike.wilson@university.edu',
      status: 'away',
    },
    {
      id: '4',
      name: 'Sarah Johnson',
      role: 'Designer',
      email: 'sarah.johnson@university.edu',
      status: 'active',
    },
  ]);

  const [meetings] = useState<Meeting[]>([
    {
      id: '1',
      title: 'Weekly Supervisor Meeting',
      date: '2024-11-15',
      time: '14:00',
      attendees: ['Dr. Sarah Johnson', 'John Doe'],
      type: 'supervisor',
    },
    {
      id: '2',
      title: 'Team Sprint Review',
      date: '2024-11-17',
      time: '10:00',
      attendees: ['John Doe', 'Jane Smith', 'Mike Wilson', 'Sarah Johnson'],
      type: 'team',
    },
    {
      id: '3',
      title: 'Mid-term Presentation Practice',
      date: '2024-11-20',
      time: '15:00',
      attendees: ['All Team Members'],
      type: 'presentation',
    },
  ]);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      author: 'Jane Smith',
      content: 'Just finished the database schema design. Ready for review!',
      timestamp: '10:30 AM',
    },
    {
      id: '2',
      author: 'John Doe',
      content: 'Great work! I\'ll review it this afternoon.',
      timestamp: '10:45 AM',
    },
    {
      id: '3',
      author: 'Mike Wilson',
      content: 'Should we schedule a team meeting to discuss the API integration?',
      timestamp: '11:15 AM',
    },
    {
      id: '4',
      author: 'Sarah Johnson',
      content: 'I\'ve uploaded the latest UI mockups to the Documents section.',
      timestamp: '2:20 PM',
    },
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const getMeetingTypeColor = (type: string) => {
    switch (type) {
      case 'supervisor': return 'bg-purple-100 text-purple-800';
      case 'team': return 'bg-blue-100 text-blue-800';
      case 'presentation': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        author: 'You',
        content: messageInput,
        timestamp: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
      };
      setMessages([...messages, newMessage]);
      setMessageInput('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Team Members */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Team Members</CardTitle>
                <CardDescription>Your project team</CardDescription>
              </div>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <UserPlus className="size-4 mr-2" />
                    Add Member
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Team Member</DialogTitle>
                    <DialogDescription>Invite a new member to your project team</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input id="name" placeholder="Enter member name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="member@university.edu" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="role">Role</Label>
                      <Input id="role" placeholder="e.g., Developer, Designer" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
                    <Button onClick={() => setDialogOpen(false)}>Send Invitation</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {teamMembers.map(member => (
                <div key={member.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="relative">
                    <Avatar>
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>{member.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <span className={`absolute bottom-0 right-0 size-3 rounded-full border-2 border-white ${getStatusColor(member.status)}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate">{member.name}</p>
                    <p className="text-sm text-gray-600">{member.role}</p>
                  </div>
                  <Badge variant="outline">{member.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Meetings */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Upcoming Meetings</CardTitle>
                <CardDescription>Schedule and manage meetings</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Calendar className="size-4 mr-2" />
                Schedule
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {meetings.map(meeting => (
                <div key={meeting.id} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h3>{meeting.title}</h3>
                    <Badge className={getMeetingTypeColor(meeting.type)}>{meeting.type}</Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                    <Calendar className="size-4" />
                    <span>{meeting.date} at {meeting.time}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">
                    Attendees: {meeting.attendees.join(', ')}
                  </p>
                  <Button size="sm" className="w-full">
                    <Video className="size-4 mr-2" />
                    Join Meeting
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Team Chat */}
      <Card>
        <CardHeader>
          <CardTitle>Team Discussion</CardTitle>
          <CardDescription>Communicate with your team members</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Messages */}
            <div className="h-[400px] overflow-y-auto space-y-3 p-4 bg-gray-50 rounded-lg">
              {messages.map(message => (
                <div key={message.id} className="flex gap-3">
                  <Avatar className="size-8">
                    <AvatarFallback>{message.author.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm">{message.author}</span>
                      <span className="text-xs text-gray-500">{message.timestamp}</span>
                    </div>
                    <div className="bg-white p-3 rounded-lg border">
                      <p className="text-sm">{message.content}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="flex gap-2">
              <Textarea
                placeholder="Type your message..."
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                className="resize-none"
                rows={2}
              />
              <Button onClick={handleSendMessage} className="self-end">
                <Send className="size-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
