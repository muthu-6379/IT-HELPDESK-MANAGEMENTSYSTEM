import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle2, Circle, Clock } from 'lucide-react';

interface Milestone {
  id: string;
  title: string;
  description: string;
  date: string;
  status: 'completed' | 'in-progress' | 'upcoming';
  deliverables: string[];
}

export function Timeline() {
  const milestones: Milestone[] = [
    {
      id: '1',
      title: 'Project Proposal',
      description: 'Submit initial project proposal and get approval',
      date: '2024-09-15',
      status: 'completed',
      deliverables: ['Project proposal document', 'Initial requirements'],
    },
    {
      id: '2',
      title: 'Literature Review',
      description: 'Complete comprehensive literature review and research',
      date: '2024-10-30',
      status: 'completed',
      deliverables: ['Literature review chapter', 'Research findings summary'],
    },
    {
      id: '3',
      title: 'System Design',
      description: 'Complete system architecture and design documents',
      date: '2024-11-20',
      status: 'in-progress',
      deliverables: ['Architecture diagrams', 'Database schema', 'UI/UX mockups'],
    },
    {
      id: '4',
      title: 'Prototype Development',
      description: 'Develop working prototype with core features',
      date: '2025-01-15',
      status: 'upcoming',
      deliverables: ['Working prototype', 'Technical documentation'],
    },
    {
      id: '5',
      title: 'Mid-term Presentation',
      description: 'Present project progress to committee',
      date: '2025-02-10',
      status: 'upcoming',
      deliverables: ['Presentation slides', 'Demo video', 'Progress report'],
    },
    {
      id: '6',
      title: 'User Testing',
      description: 'Conduct comprehensive user testing and gather feedback',
      date: '2025-03-01',
      status: 'upcoming',
      deliverables: ['Testing results', 'User feedback report', 'Improvements list'],
    },
    {
      id: '7',
      title: 'Final Implementation',
      description: 'Complete final version with all features implemented',
      date: '2025-04-01',
      status: 'upcoming',
      deliverables: ['Complete application', 'Source code', 'Deployment guide'],
    },
    {
      id: '8',
      title: 'Final Report & Presentation',
      description: 'Submit final report and present to evaluation committee',
      date: '2025-04-30',
      status: 'upcoming',
      deliverables: ['Final report', 'Presentation', 'Project poster'],
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="size-5 text-green-600" />;
      case 'in-progress':
        return <Clock className="size-5 text-blue-600" />;
      case 'upcoming':
        return <Circle className="size-5 text-gray-400" />;
      default:
        return <Circle className="size-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'upcoming': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Project Timeline</CardTitle>
        <CardDescription>Track milestones and deliverables throughout the project</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-[9px] top-0 bottom-0 w-0.5 bg-gray-200" />

          {/* Milestones */}
          <div className="space-y-8">
            {milestones.map((milestone, index) => (
              <div key={milestone.id} className="relative pl-8">
                {/* Icon */}
                <div className="absolute left-0 top-0 bg-white">
                  {getStatusIcon(milestone.status)}
                </div>

                {/* Content */}
                <div className="bg-white border rounded-lg p-4 hover:shadow-sm transition-shadow">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div>
                      <h3 className="mb-1">{milestone.title}</h3>
                      <p className="text-sm text-gray-600">{milestone.description}</p>
                    </div>
                    <Badge className={getStatusColor(milestone.status)}>
                      {milestone.status}
                    </Badge>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                    <Clock className="size-4" />
                    <span>{milestone.date}</span>
                  </div>

                  {/* Deliverables */}
                  <div>
                    <p className="text-sm mb-2">Deliverables:</p>
                    <ul className="space-y-1">
                      {milestone.deliverables.map((deliverable, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-center gap-2">
                          <span className="size-1.5 rounded-full bg-gray-400" />
                          {deliverable}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
