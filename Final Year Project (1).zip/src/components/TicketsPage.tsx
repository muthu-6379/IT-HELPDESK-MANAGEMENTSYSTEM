import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Search, Plus, Filter, Users, Clock } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import type { Page } from '../App';

interface TicketsPageProps {
  onViewTicket: (ticketId: string) => void;
  onNavigate: (page: Page) => void;
}

export function TicketsPage({ onViewTicket, onNavigate }: TicketsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');

  const allTickets = [
    { id: 'TKT-1001', title: 'Cannot access email account', priority: 'high', status: 'open', category: 'Email', user: 'John Smith', date: '2024-11-13', time: '5 min ago' },
    { id: 'TKT-1002', title: 'Printer not working on 3rd floor', priority: 'medium', status: 'in-progress', category: 'Hardware', user: 'Sarah Johnson', date: '2024-11-13', time: '15 min ago' },
    { id: 'TKT-1003', title: 'VPN connection issues', priority: 'high', status: 'open', category: 'Network', user: 'Mike Wilson', date: '2024-11-13', time: '1 hour ago' },
    { id: 'TKT-1004', title: 'Software installation request', priority: 'low', status: 'in-progress', category: 'Software', user: 'Emily Davis', date: '2024-11-13', time: '2 hours ago' },
    { id: 'TKT-1005', title: 'Password reset needed', priority: 'medium', status: 'open', category: 'Account', user: 'David Brown', date: '2024-11-13', time: '3 hours ago' },
    { id: 'TKT-1006', title: 'Monitor display flickering', priority: 'low', status: 'resolved', category: 'Hardware', user: 'Lisa Anderson', date: '2024-11-12', time: '1 day ago' },
    { id: 'TKT-1007', title: 'File server access denied', priority: 'high', status: 'in-progress', category: 'Access', user: 'Robert Taylor', date: '2024-11-12', time: '1 day ago' },
    { id: 'TKT-1008', title: 'Laptop running slow', priority: 'medium', status: 'open', category: 'Hardware', user: 'Jennifer White', date: '2024-11-12', time: '1 day ago' },
    { id: 'TKT-1009', title: 'Install Adobe Creative Suite', priority: 'low', status: 'resolved', category: 'Software', user: 'Chris Martin', date: '2024-11-11', time: '2 days ago' },
    { id: 'TKT-1010', title: 'Outlook calendar sync issue', priority: 'medium', status: 'resolved', category: 'Email', user: 'Amanda Lee', date: '2024-11-11', time: '2 days ago' },
  ];

  const filterTickets = (status: string) => {
    return allTickets.filter(ticket => {
      const matchesStatus = status === 'all' || ticket.status === status;
      const matchesSearch = ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           ticket.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           ticket.user.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPriority = filterPriority === 'all' || ticket.priority === filterPriority;
      const matchesCategory = filterCategory === 'all' || ticket.category === filterCategory;
      return matchesStatus && matchesSearch && matchesPriority && matchesCategory;
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-100 text-blue-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const openTickets = filterTickets('open');
  const inProgressTickets = filterTickets('in-progress');
  const resolvedTickets = filterTickets('resolved');
  const allFilteredTickets = filterTickets('all');

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-gray-900 mb-2">Support Tickets</h1>
          <p className="text-gray-600">Manage and track all support requests</p>
        </div>
        <Button onClick={() => onNavigate('create-ticket')}>
          <Plus className="size-4 mr-2" />
          Create Ticket
        </Button>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-4 text-gray-400" />
              <Input
                placeholder="Search tickets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger className="w-[140px]">
                  <Filter className="size-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Hardware">Hardware</SelectItem>
                  <SelectItem value="Software">Software</SelectItem>
                  <SelectItem value="Network">Network</SelectItem>
                  <SelectItem value="Email">Email</SelectItem>
                  <SelectItem value="Account">Account</SelectItem>
                  <SelectItem value="Access">Access</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tickets Tabs */}
      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all">All ({allFilteredTickets.length})</TabsTrigger>
          <TabsTrigger value="open">Open ({openTickets.length})</TabsTrigger>
          <TabsTrigger value="in-progress">In Progress ({inProgressTickets.length})</TabsTrigger>
          <TabsTrigger value="resolved">Resolved ({resolvedTickets.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <TicketList tickets={allFilteredTickets} onViewTicket={onViewTicket} getPriorityColor={getPriorityColor} getStatusColor={getStatusColor} />
        </TabsContent>

        <TabsContent value="open">
          <TicketList tickets={openTickets} onViewTicket={onViewTicket} getPriorityColor={getPriorityColor} getStatusColor={getStatusColor} />
        </TabsContent>

        <TabsContent value="in-progress">
          <TicketList tickets={inProgressTickets} onViewTicket={onViewTicket} getPriorityColor={getPriorityColor} getStatusColor={getStatusColor} />
        </TabsContent>

        <TabsContent value="resolved">
          <TicketList tickets={resolvedTickets} onViewTicket={onViewTicket} getPriorityColor={getPriorityColor} getStatusColor={getStatusColor} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface TicketListProps {
  tickets: any[];
  onViewTicket: (ticketId: string) => void;
  getPriorityColor: (priority: string) => string;
  getStatusColor: (status: string) => string;
}

function TicketList({ tickets, onViewTicket, getPriorityColor, getStatusColor }: TicketListProps) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-3">
          {tickets.map((ticket) => (
            <div
              key={ticket.id}
              className="flex items-center gap-4 p-4 border rounded-lg hover:shadow-sm transition-all cursor-pointer"
              onClick={() => onViewTicket(ticket.id)}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm text-gray-600">{ticket.id}</span>
                  <Badge className={getPriorityColor(ticket.priority)}>{ticket.priority}</Badge>
                  <Badge variant="outline">{ticket.category}</Badge>
                </div>
                <p className="mb-2 truncate">{ticket.title}</p>
                <div className="flex items-center gap-3 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Users className="size-4" />
                    <span>{ticket.user}</span>
                  </div>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    <Clock className="size-4" />
                    <span>{ticket.time}</span>
                  </div>
                </div>
              </div>
              <Badge className={getStatusColor(ticket.status)}>{ticket.status}</Badge>
            </div>
          ))}
          {tickets.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <p>No tickets found</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
