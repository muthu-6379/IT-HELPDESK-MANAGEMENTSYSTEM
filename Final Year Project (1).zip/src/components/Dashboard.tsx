import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Ticket, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  TrendingUp, 
  Users,
  Plus,
  BookOpen,
  BarChart3
} from 'lucide-react';
import type { Page } from '../App';

interface DashboardProps {
  onNavigate: (page: Page) => void;
  onViewTicket: (ticketId: string) => void;
}

export function Dashboard({ onNavigate, onViewTicket }: DashboardProps) {
  const stats = [
    { label: 'Open Tickets', value: '24', icon: Ticket, color: 'text-blue-600', bgColor: 'bg-blue-100', trend: '+12%' },
    { label: 'In Progress', value: '18', icon: Clock, color: 'text-yellow-600', bgColor: 'bg-yellow-100', trend: '+5%' },
    { label: 'Resolved', value: '156', icon: CheckCircle2, color: 'text-green-600', bgColor: 'bg-green-100', trend: '+23%' },
    { label: 'Urgent', value: '5', icon: AlertCircle, color: 'text-red-600', bgColor: 'bg-red-100', trend: '-8%' },
  ];

  const recentTickets = [
    { id: 'TKT-1001', title: 'Cannot access email account', priority: 'high', status: 'open', user: 'John Smith', time: '5 min ago' },
    { id: 'TKT-1002', title: 'Printer not working on 3rd floor', priority: 'medium', status: 'in-progress', user: 'Sarah Johnson', time: '15 min ago' },
    { id: 'TKT-1003', title: 'VPN connection issues', priority: 'high', status: 'open', user: 'Mike Wilson', time: '1 hour ago' },
    { id: 'TKT-1004', title: 'Software installation request', priority: 'low', status: 'in-progress', user: 'Emily Davis', time: '2 hours ago' },
    { id: 'TKT-1005', title: 'Password reset needed', priority: 'medium', status: 'open', user: 'David Brown', time: '3 hours ago' },
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-100 text-blue-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">Welcome back! Here's what's happening today.</p>
        </div>
        <Button onClick={() => onNavigate('create-ticket')}>
          <Plus className="size-4 mr-2" />
          Create Ticket
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.bgColor} p-3 rounded-lg`}>
                  <stat.icon className={`size-6 ${stat.color}`} />
                </div>
                <div className="flex items-center gap-1 text-sm text-green-600">
                  <TrendingUp className="size-4" />
                  {stat.trend}
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-3xl">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Recent Tickets */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Recent Tickets</CardTitle>
                <CardDescription>Latest support requests</CardDescription>
              </div>
              <Button variant="outline" onClick={() => onNavigate('tickets')}>View All</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentTickets.map((ticket) => (
                <div 
                  key={ticket.id} 
                  className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                  onClick={() => onViewTicket(ticket.id)}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm text-gray-600">{ticket.id}</span>
                      <Badge className={getPriorityColor(ticket.priority)}>{ticket.priority}</Badge>
                    </div>
                    <p className="mb-1 truncate">{ticket.title}</p>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Users className="size-4" />
                      <span>{ticket.user}</span>
                      <span>•</span>
                      <span>{ticket.time}</span>
                    </div>
                  </div>
                  <Badge className={getStatusColor(ticket.status)}>{ticket.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start" onClick={() => onNavigate('create-ticket')}>
              <Plus className="size-4 mr-2" />
              Create New Ticket
            </Button>
            <Button variant="outline" className="w-full justify-start" onClick={() => onNavigate('tickets')}>
              <Ticket className="size-4 mr-2" />
              View All Tickets
            </Button>
            <Button variant="outline" className="w-full justify-start" onClick={() => onNavigate('knowledge-base')}>
              <BookOpen className="size-4 mr-2" />
              Browse Knowledge Base
            </Button>
            <Button variant="outline" className="w-full justify-start" onClick={() => onNavigate('reports')}>
              <BarChart3 className="size-4 mr-2" />
              View Reports
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}