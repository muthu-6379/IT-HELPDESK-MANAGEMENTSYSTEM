import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Search, UserPlus, Mail, Phone, MoreVertical } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

export function UsersPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const users = [
    { id: '1', name: 'John Smith', email: 'john.smith@company.com', role: 'user', department: 'Sales', phone: '+1 234 567 8901', status: 'active', tickets: 12 },
    { id: '2', name: 'Sarah Johnson', email: 'sarah.johnson@company.com', role: 'user', department: 'Marketing', phone: '+1 234 567 8902', status: 'active', tickets: 8 },
    { id: '3', name: 'Mike Wilson', email: 'mike.wilson@company.com', role: 'user', department: 'Engineering', phone: '+1 234 567 8903', status: 'active', tickets: 15 },
    { id: '4', name: 'Emily Davis', email: 'emily.davis@company.com', role: 'user', department: 'HR', phone: '+1 234 567 8904', status: 'active', tickets: 5 },
  ];

  const agents = [
    { id: '5', name: 'Sarah Wilson', email: 'sarah.wilson@company.com', role: 'agent', department: 'IT Support', phone: '+1 234 567 8905', status: 'active', tickets: 45 },
    { id: '6', name: 'David Brown', email: 'david.brown@company.com', role: 'agent', department: 'IT Support', phone: '+1 234 567 8906', status: 'active', tickets: 38 },
    { id: '7', name: 'Lisa Anderson', email: 'lisa.anderson@company.com', role: 'agent', department: 'IT Support', phone: '+1 234 567 8907', status: 'away', tickets: 42 },
  ];

  const admins = [
    { id: '8', name: 'Robert Taylor', email: 'robert.taylor@company.com', role: 'admin', department: 'IT Management', phone: '+1 234 567 8908', status: 'active', tickets: 0 },
    { id: '9', name: 'Jennifer White', email: 'jennifer.white@company.com', role: 'admin', department: 'IT Management', phone: '+1 234 567 8909', status: 'active', tickets: 0 },
  ];

  const filterUsers = (userList: any[]) => {
    return userList.filter(user =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.department.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-purple-100 text-purple-800';
      case 'agent': return 'bg-blue-100 text-blue-800';
      case 'user': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-gray-900 mb-2">User Management</h1>
          <p className="text-gray-600">Manage users, agents, and administrators</p>
        </div>
        <Button>
          <UserPlus className="size-4 mr-2" />
          Add User
        </Button>
      </div>

      {/* Search */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-4 text-gray-400" />
            <Input
              placeholder="Search users by name, email, or department..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Users Tabs */}
      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all">All Users ({users.length + agents.length + admins.length})</TabsTrigger>
          <TabsTrigger value="users">Users ({users.length})</TabsTrigger>
          <TabsTrigger value="agents">Agents ({agents.length})</TabsTrigger>
          <TabsTrigger value="admins">Admins ({admins.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <UserList users={[...admins, ...agents, ...users]} searchQuery={searchQuery} getRoleColor={getRoleColor} getStatusColor={getStatusColor} />
        </TabsContent>

        <TabsContent value="users">
          <UserList users={filterUsers(users)} searchQuery={searchQuery} getRoleColor={getRoleColor} getStatusColor={getStatusColor} />
        </TabsContent>

        <TabsContent value="agents">
          <UserList users={filterUsers(agents)} searchQuery={searchQuery} getRoleColor={getRoleColor} getStatusColor={getStatusColor} />
        </TabsContent>

        <TabsContent value="admins">
          <UserList users={filterUsers(admins)} searchQuery={searchQuery} getRoleColor={getRoleColor} getStatusColor={getStatusColor} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface UserListProps {
  users: any[];
  searchQuery: string;
  getRoleColor: (role: string) => string;
  getStatusColor: (status: string) => string;
}

function UserList({ users, searchQuery, getRoleColor, getStatusColor }: UserListProps) {
  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-3">
          {filteredUsers.map((user) => (
            <div
              key={user.id}
              className="flex items-center gap-4 p-4 border rounded-lg hover:shadow-sm transition-all"
            >
              <div className="relative">
                <Avatar className="size-12">
                  <AvatarFallback>{user.name.split(' ').map((n: string) => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <span className={`absolute bottom-0 right-0 size-3 rounded-full border-2 border-white ${getStatusColor(user.status)}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <p className="truncate">{user.name}</p>
                  <Badge className={getRoleColor(user.role)}>{user.role}</Badge>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Mail className="size-4" />
                    <span className="truncate">{user.email}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Phone className="size-4" />
                    <span>{user.phone}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                  <span>{user.department}</span>
                  <span>•</span>
                  <span>{user.tickets} tickets</span>
                </div>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <MoreVertical className="size-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>View Profile</DropdownMenuItem>
                  <DropdownMenuItem>Edit User</DropdownMenuItem>
                  <DropdownMenuItem>View Tickets</DropdownMenuItem>
                  <DropdownMenuItem>Send Email</DropdownMenuItem>
                  <DropdownMenuItem className="text-red-600">Deactivate</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ))}
          {filteredUsers.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <p>No users found</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
