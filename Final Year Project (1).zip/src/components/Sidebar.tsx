import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { 
  LayoutDashboard, 
  Ticket, 
  Users, 
  BookOpen, 
  BarChart3, 
  Settings, 
  LogOut,
  Headphones 
} from 'lucide-react';
import type { Page, User } from '../App';

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
  currentUser: User | null;
}

export function Sidebar({ currentPage, onNavigate, onLogout, currentUser }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['admin', 'agent', 'user'] },
    { id: 'tickets', label: 'Tickets', icon: Ticket, roles: ['admin', 'agent', 'user'] },
    { id: 'users', label: 'Users', icon: Users, roles: ['admin'] },
    { id: 'knowledge-base', label: 'Knowledge Base', icon: BookOpen, roles: ['admin', 'agent', 'user'] },
    { id: 'reports', label: 'Reports', icon: BarChart3, roles: ['admin', 'agent'] },
    { id: 'settings', label: 'Settings', icon: Settings, roles: ['admin', 'agent', 'user'] },
  ];

  const filteredMenuItems = menuItems.filter(item => 
    currentUser && item.roles.includes(currentUser.role)
  );

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-white border-r flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-blue-600 to-indigo-600 p-2 rounded-lg">
            <Headphones className="size-6 text-white" />
          </div>
          <div>
            <h1 className="text-gray-900">IT Desk</h1>
            <p className="text-xs text-gray-600">Support Portal</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {filteredMenuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id as Page)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Icon className="size-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t">
        <div className="flex items-center gap-3 mb-3">
          <Avatar>
            <AvatarImage src="" />
            <AvatarFallback>
              {currentUser?.name.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm truncate">{currentUser?.name}</p>
            <p className="text-xs text-gray-600 capitalize">{currentUser?.role}</p>
          </div>
        </div>
        <Button variant="outline" className="w-full" onClick={onLogout}>
          <LogOut className="size-4 mr-2" />
          Logout
        </Button>
      </div>
    </aside>
  );
}
