import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function TestBackendConnection() {
  const [status, setStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const testConnection = async () => {
    setStatus('testing');
    setMessage('Testing backend connection...');

    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-470bad71/health`;
      console.log('Testing connection to:', url);

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });

      const data = await response.json();
      console.log('Health check response:', data);

      if (response.ok && data.status === 'ok') {
        setStatus('success');
        setMessage('✅ Backend connected successfully!');
      } else {
        throw new Error('Backend returned unexpected response');
      }
    } catch (error: any) {
      console.error('Connection error:', error);
      setStatus('error');
      setMessage(`❌ Connection failed: ${error.message}`);
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Backend Connection Test</CardTitle>
        <CardDescription>Test if the backend server is running</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm space-y-2">
          <p><strong>Project ID:</strong> {projectId}</p>
          <p><strong>Server URL:</strong> https://{projectId}.supabase.co/functions/v1/make-server-470bad71</p>
        </div>

        {status !== 'idle' && (
          <div className={`flex items-center gap-2 p-3 rounded-lg ${
            status === 'success' ? 'bg-green-50 text-green-700' :
            status === 'error' ? 'bg-red-50 text-red-700' :
            'bg-blue-50 text-blue-700'
          }`}>
            {status === 'testing' && <Loader2 className="size-5 animate-spin" />}
            {status === 'success' && <CheckCircle2 className="size-5" />}
            {status === 'error' && <XCircle className="size-5" />}
            <span>{message}</span>
          </div>
        )}

        <Button onClick={testConnection} disabled={status === 'testing'} className="w-full">
          {status === 'testing' ? 'Testing...' : 'Test Connection'}
        </Button>
      </CardContent>
    </Card>
  );
}
