import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Calendar, CheckCircle2, Clock, FileText, Users, AlertCircle } from 'lucide-react';

export function ProjectDashboard() {
  const projectInfo = {
    title: 'AI-Powered Student Learning Platform',
    status: 'In Progress',
    progress: 65,
    startDate: '2024-09-01',
    endDate: '2025-04-30',
    supervisor: 'Dr. Sarah Johnson',
  };

  const stats = [
    { label: 'Tasks Completed', value: '23/35', icon: CheckCircle2, color: 'text-green-600', bgColor: 'bg-green-100' },
    { label: 'Days Remaining', value: '158', icon: Clock, color: 'text-blue-600', bgColor: 'bg-blue-100' },
    { label: 'Documents', value: '12', icon: FileText, color: 'text-purple-600', bgColor: 'bg-purple-100' },
    { label: 'Team Members', value: '4', icon: Users, color: 'text-orange-600', bgColor: 'bg-orange-100' },
  ];

  const upcomingMilestones = [
    { title: 'Literature Review Submission', date: '2024-12-15', status: 'upcoming' },
    { title: 'Prototype Demo', date: '2025-01-20', status: 'upcoming' },
    { title: 'Mid-term Presentation', date: '2025-02-10', status: 'upcoming' },
  ];

  const recentActivity = [
    { action: 'Completed task: Database Schema Design', time: '2 hours ago', type: 'success' },
    { action: 'Uploaded document: Research Proposal v2', time: '5 hours ago', type: 'info' },
    { action: 'Meeting scheduled with supervisor', time: '1 day ago', type: 'info' },
    { action: 'Overdue: User Testing Report', time: '2 days ago', type: 'warning' },
  ];

  return (
    <div className="space-y-6">
      {/* Project Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle>{projectInfo.title}</CardTitle>
              <CardDescription>Supervisor: {projectInfo.supervisor}</CardDescription>
            </div>
            <Badge variant="default">{projectInfo.status}</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-600">Overall Progress</span>
              <span className="text-sm">{projectInfo.progress}%</span>
            </div>
            <Progress value={projectInfo.progress} />
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Calendar className="size-4" />
            <span>{projectInfo.startDate} to {projectInfo.endDate}</span>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                  <p className="mt-1">{stat.value}</p>
                </div>
                <div className={`${stat.bgColor} p-3 rounded-lg`}>
                  <stat.icon className={`size-5 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Upcoming Milestones */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Milestones</CardTitle>
            <CardDescription>Key deadlines approaching</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingMilestones.map((milestone, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Calendar className="size-4 text-gray-500" />
                    <div>
                      <p className="text-sm">{milestone.title}</p>
                      <p className="text-xs text-gray-500">{milestone.date}</p>
                    </div>
                  </div>
                  <Badge variant="outline">Upcoming</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest updates on your project</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  {activity.type === 'success' && <CheckCircle2 className="size-4 text-green-600 mt-0.5 flex-shrink-0" />}
                  {activity.type === 'info' && <FileText className="size-4 text-blue-600 mt-0.5 flex-shrink-0" />}
                  {activity.type === 'warning' && <AlertCircle className="size-4 text-orange-600 mt-0.5 flex-shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">{activity.action}</p>
                    <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
