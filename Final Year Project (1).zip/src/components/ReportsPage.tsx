import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Clock, CheckCircle2 } from 'lucide-react';

export function ReportsPage() {
  const ticketsByStatus = [
    { name: 'Open', value: 24, color: '#3B82F6' },
    { name: 'In Progress', value: 18, color: '#F59E0B' },
    { name: 'Resolved', value: 156, color: '#10B981' },
    { name: 'Closed', value: 342, color: '#6B7280' },
  ];

  const ticketsByCategory = [
    { category: 'Hardware', count: 45 },
    { category: 'Software', count: 38 },
    { category: 'Network', count: 32 },
    { category: 'Email', count: 28 },
    { category: 'Account', count: 24 },
    { category: 'Other', count: 18 },
  ];

  const ticketTrend = [
    { month: 'Jun', tickets: 42 },
    { month: 'Jul', tickets: 56 },
    { month: 'Aug', tickets: 48 },
    { month: 'Sep', tickets: 62 },
    { month: 'Oct', tickets: 58 },
    { month: 'Nov', tickets: 72 },
  ];

  const responseTimeData = [
    { day: 'Mon', avgTime: 2.4 },
    { day: 'Tue', avgTime: 1.8 },
    { day: 'Wed', avgTime: 2.1 },
    { day: 'Thu', avgTime: 1.6 },
    { day: 'Fri', avgTime: 2.8 },
  ];

  const stats = [
    {
      label: 'Avg Response Time',
      value: '2.1 hrs',
      change: '-12%',
      isPositive: true,
      icon: Clock,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
    },
    {
      label: 'Resolution Rate',
      value: '94%',
      change: '+5%',
      isPositive: true,
      icon: CheckCircle2,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
    },
    {
      label: 'Customer Satisfaction',
      value: '4.8/5',
      change: '+0.3',
      isPositive: true,
      icon: TrendingUp,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
    },
    {
      label: 'Reopened Tickets',
      value: '3.2%',
      change: '-1.5%',
      isPositive: true,
      icon: TrendingDown,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100',
    },
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Reports & Analytics</h1>
        <p className="text-gray-600">Track performance metrics and ticket statistics</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.bgColor} p-3 rounded-lg`}>
                  <stat.icon className={`size-6 ${stat.color}`} />
                </div>
                <div className={`flex items-center gap-1 text-sm ${stat.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.isPositive ? <TrendingUp className="size-4" /> : <TrendingDown className="size-4" />}
                  {stat.change}
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-3xl">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2 mb-8">
        {/* Ticket Trend */}
        <Card>
          <CardHeader>
            <CardTitle>Ticket Trend</CardTitle>
            <CardDescription>Monthly ticket volume over the last 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={ticketTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="tickets" stroke="#3B82F6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Tickets by Status */}
        <Card>
          <CardHeader>
            <CardTitle>Tickets by Status</CardTitle>
            <CardDescription>Current distribution of ticket statuses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={ticketsByStatus}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {ticketsByStatus.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Tickets by Category */}
        <Card>
          <CardHeader>
            <CardTitle>Tickets by Category</CardTitle>
            <CardDescription>Distribution across different support categories</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={ticketsByCategory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="category" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Response Time */}
        <Card>
          <CardHeader>
            <CardTitle>Average Response Time</CardTitle>
            <CardDescription>Response time in hours by day of week</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={responseTimeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="avgTime" fill="#F59E0B" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
