# Backend OTP Registration System - Setup Guide

## ✅ What Has Been Configured

### 1. Backend Server (Supabase Edge Functions)
**Location:** `/supabase/functions/server/index.tsx`

**Endpoints Created:**
- `GET /make-server-470bad71/health` - Health check endpoint
- `POST /make-server-470bad71/register/send-otp` - Send OTP to email
- `POST /make-server-470bad71/register/verify-otp` - Verify OTP and register user

### 2. Frontend (React)
**Location:** `/components/RegisterPage.tsx`

**Features:**
- Pre-filled with user data (Muthulakshmi, mlakshmi9101@gmail.com, 6379359101)
- Two-step OTP registration process
- Backend connection test button
- Real-time error handling and success messages
- Comprehensive console logging for debugging

## 🚀 How to Use the OTP Registration

### Step 1: Test Backend Connection
1. Go to the Register page
2. Click the "🔧 Test Backend Connection" button
3. Check console for connection status
4. Should see "✅ Backend is connected and working!"

### Step 2: Send OTP
1. Your details are pre-filled:
   - Name: Muthulakshmi
   - Email: mlakshmi9101@gmail.com
   - Phone: 6379359101
2. Select a department (optional)
3. Click "📧 Send OTP to Email"
4. Wait for confirmation message

### Step 3: Verify OTP
1. Check your email inbox at mlakshmi9101@gmail.com
2. Also check spam/junk folder
3. Enter the 6-digit OTP code
4. Click "✓ Verify OTP & Complete Registration"
5. See success message and redirect to login

## 🔧 Backend Architecture

```
Frontend (RegisterPage.tsx)
    ↓
    ↓ HTTPS Request
    ↓
Supabase Edge Function (Hono Server)
    ↓
    ↓ Supabase Auth API
    ↓
Supabase Auth Service
    ↓
    ↓ Email Service
    ↓
Your Email: mlakshmi9101@gmail.com
```

## 📊 API Endpoints Details

### Send OTP Endpoint
```
POST https://hisyfwvqnrdbkoazdliw.supabase.co/functions/v1/make-server-470bad71/register/send-otp

Headers:
- Content-Type: application/json
- Authorization: Bearer {publicAnonKey}

Body:
{
  "email": "mlakshmi9101@gmail.com",
  "fullName": "Muthulakshmi",
  "department": "engineering",
  "phone": "6379359101"
}

Success Response:
{
  "success": true,
  "message": "OTP has been sent to mlakshmi9101@gmail.com. Please check your inbox."
}
```

### Verify OTP Endpoint
```
POST https://hisyfwvqnrdbkoazdliw.supabase.co/functions/v1/make-server-470bad71/register/verify-otp

Headers:
- Content-Type: application/json
- Authorization: Bearer {publicAnonKey}

Body:
{
  "email": "mlakshmi9101@gmail.com",
  "otp": "123456",
  "fullName": "Muthulakshmi",
  "department": "engineering",
  "phone": "6379359101"
}

Success Response:
{
  "success": true,
  "message": "Registration successful!",
  "user": {
    "id": "user-uuid",
    "email": "mlakshmi9101@gmail.com",
    "fullName": "Muthulakshmi"
  }
}
```

## 🐛 Debugging Guide

### Check Browser Console
Open Developer Tools (F12) and look for these logs:
- 🔍 Testing backend connection
- 🚀 Sending OTP request
- 📨 Response status
- 📦 Response data
- ✅ Success messages
- ❌ Error messages

### Common Issues

#### 1. "Network Error: Unable to connect to server"
**Cause:** App is not accessible or internet connection issue
**Solution:** 
- Make sure you're viewing the app in Figma Make preview
- Check your internet connection
- Click "🔧 Test Backend Connection" to verify

#### 2. "Failed to send OTP"
**Cause:** Supabase email service issue
**Solution:**
- Supabase's default email service has rate limits
- Check if email address is valid
- Try again after a few minutes

#### 3. "Invalid or expired OTP"
**Cause:** Wrong OTP code or OTP expired
**Solution:**
- OTPs typically expire in 60 seconds to 5 minutes
- Click "Resend OTP" to get a new code
- Make sure you're entering the correct 6-digit code

#### 4. Email not received
**Solution:**
- Check spam/junk folder
- Wait 1-2 minutes for email delivery
- Verify email address is correct
- Click "Resend OTP"

## ⚙️ Technical Details

### Environment Variables (Auto-configured)
- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_ANON_KEY` - Public anonymous key
- `SUPABASE_SERVICE_ROLE_KEY` - Service role key (server-side only)

### Security
- ✅ OTP codes are generated and sent by Supabase Auth
- ✅ OTPs are time-limited (expire after a few minutes)
- ✅ All API calls are authenticated
- ✅ User data is stored securely in KV store
- ✅ Service role key never exposed to frontend

### User Data Storage
After successful registration, user data is stored in the KV store:
```javascript
{
  id: "user-uuid",
  email: "mlakshmi9101@gmail.com",
  fullName: "Muthulakshmi",
  department: "engineering",
  phone: "6379359101",
  role: "user",
  createdAt: "2024-01-01T00:00:00.000Z"
}
```

## 📝 Next Steps

1. **Test the flow** - Try registering with your email
2. **Check console logs** - Monitor the entire process
3. **Verify email delivery** - Make sure you receive the OTP
4. **Complete registration** - Enter OTP and see success message

## ⚠️ Important Notes

- This is a development/prototype environment
- Supabase's default email service is rate-limited
- For production, configure a custom email provider in Supabase
- OTP codes expire quickly (typically 1-5 minutes)
- The backend is fully deployed and ready to use

## 🎯 Testing Checklist

- [ ] Click "Test Backend Connection" button
- [ ] See "✅ Backend is connected and working!"
- [ ] Click "📧 Send OTP to Email"
- [ ] Check console for request logs
- [ ] Check email inbox (mlakshmi9101@gmail.com)
- [ ] Check spam folder if needed
- [ ] Enter 6-digit OTP code
- [ ] Click "Verify OTP & Complete Registration"
- [ ] See success message
- [ ] Redirected to login page

---

**Your Backend is Ready! 🎉**

The OTP registration system is fully connected and configured. Just open the app and try registering with your email: mlakshmi9101@gmail.com
